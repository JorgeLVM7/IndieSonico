<div class="col-sm-3">
    <div class="row bw">
        <a class="twitter-timeline" data-lang="es" data-width="100%" data-height="225" data-dnt="false" href="https://twitter.com/IndieSonico?ref_src=twsrc%5Etfw">Tweets by IndieSonico</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
    </div>
    <div class="row bw">
        <h4>Siguenos</h4>
    </div>
</div>