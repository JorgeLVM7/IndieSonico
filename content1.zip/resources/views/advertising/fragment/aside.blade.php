<p>
    Desde aquí podemos crear, editar y eliminar los articulos
</p>