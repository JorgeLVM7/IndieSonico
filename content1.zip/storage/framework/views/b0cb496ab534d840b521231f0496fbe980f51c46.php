<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h3 class="text-center">Vista Previa </h3>
            <div class="row justify-content-end">
                <a href="<?php echo e(route('users.edit', $users->id)); ?>" class="btn btn-outline-warning ">Editar</a>
            </div>
            <h4>
                <?php echo e($users->name); ?>


            </h4>
            <p><?php echo e($users->last_name); ?></p>
            <p><?php echo e($users->email); ?></p>
            <p><?php echo e($users->user); ?></p>
            <p><?php echo e($users->level); ?></p>

            
        </div>
    </div>
    <div class="row justify-content-center">
        <a class="btn btn-outline-dark" href="<?php echo e(route('users.index')); ?>">Regresar</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>