<div class="row">
    <div class="col-sm-6">
        <div class="form-group">
            <?php echo Form::label('name','Nombre'); ?>

            <?php echo Form::text('name', null,['class'=>'form-control']); ?>

        </div>

    </div>
    <div class="col-sm-6">
        <div class="form-group">
            <?php echo Form::label('email','Correo'); ?>

            <?php echo Form::text('email', null,['class'=>'form-control']); ?>

        </div>

    </div>
    <div class="col-12">
        <div class="form-group">
            <?php echo Form::label('mensaje','Mensaje'); ?>

            <?php echo Form::textarea('mensaje', null,['class'=>'form-control', 'rows'=>'10']); ?>

        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::submit('Enviar',['class'=>'btn btn-primary', 'style'=>"cursor: pointer"]); ?>


        </div>
    </div>
</div>
