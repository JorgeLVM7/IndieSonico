<?php $__env->startSection('content'); ?>
        
            
                
                    
                        
                    
                
                
                    
                        
                            
                            
                            
                            
                            
                        
                    
                    
                    
                        
                            
                            
                            
                            
                            
                                
                                    

                                    


                                
                            
                        
                        
                    
                
            
        



    <div class="row">
        <div class="col-12">
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active approvals" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true"> <b>No Aprobado</b></a>
                    <a class="nav-item nav-link approvals" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false"><b>Rechazado</b></a>
                    <a class="nav-item nav-link approvals" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false"><b>Aprobado</b></a>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">

                
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">


                    <div class="row">
                        <div class="col-12">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>Encabezado</th>
                                    <th>Categoría</th>
                                    <th>Autor</th>
                                    <th>Estado</th>
                                    <th colspan="3">Acciones</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($approval->head); ?></td>
                                        <td><?php echo e($approval->category); ?></td>
                                        <td><?php echo e($approval->autor); ?></td>
                                        <td><?php echo e($approval->approve); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-toggle" >
                                                <a href="<?php echo e(route('approvals.show', $approval->id)); ?>" class="btn btn-outline-success" role="button" aria-pressed="true">Ver</a>

                                                <a href="<?php echo e(route('approvals.edit', $approval->id)); ?>" class="btn btn-outline-warning"  role="button" aria-pressed="true">Editar</a>


                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>

                
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">

                    <div class="row">
                        <div class="col-12">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>Encabezado</th>
                                    <th>Categoría</th>
                                    <th>Autor</th>
                                    <th>Estado</th>
                                    <th colspan="3">Acciones</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $approvals_decline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approval_decline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($approval_decline->head); ?></td>
                                        <td><?php echo e($approval_decline->category); ?></td>
                                        <td><?php echo e($approval_decline->autor); ?></td>
                                        <td><?php echo e($approval_decline->approve); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-toggle" >
                                                <a href="<?php echo e(route('approvals.show', $approval_decline->id)); ?>" class="btn btn-outline-success" role="button" aria-pressed="true">Ver</a>

                                                <a href="<?php echo e(route('approvals.edit', $approval_decline->id)); ?>" class="btn btn-outline-warning"  role="button" aria-pressed="true">Editar</a>


                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

                
                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">

                    <div class="row">
                        <div class="col-12">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>Encabezado</th>
                                    <th>Categoría</th>
                                    <th>Autor</th>
                                    <th>Estado</th>
                                    <th colspan="3">Acciones</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $approvals_acepted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approval_acepted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($approval_acepted->head); ?></td>
                                        <td><?php echo e($approval_acepted->category); ?></td>
                                        <td><?php echo e($approval_acepted->autor); ?></td>
                                        <td><?php echo e($approval_acepted->approve); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-toggle" >
                                                <a href="<?php echo e(route('approvals.show', $approval_acepted->id)); ?>" class="btn btn-outline-success" role="button" aria-pressed="true">Ver</a>

                                                <a href="<?php echo e(route('approvals.edit', $approval_acepted->id)); ?>" class="btn btn-outline-warning"  role="button" aria-pressed="true">Editar</a>


                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>