<?php $__env->startSection('content'); ?>
    <br>
    <div id="carouselExampleSlidesOnly" class=" carousel slide fixed-absolute ahi" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100 top-ten" src="icons/1.png" alt="First slide">
            </div>
            <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item ">
                    <img class="d-block w-100 top-ten logo" src="images/<?php echo e($top->path); ?>" alt="">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-9 scroll bw">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="<?php echo e($article->id); ?>" class="card-body">

                        
                        <div class="row ">
                            <h3 class="card-title"><b><?php echo e($article ->head); ?></b></h3>
                        </div>
                        <div class="row ">
                            <img class="card-img-top img-articles" src="images/<?php echo e($article->path); ?>" alt="Card image cap">
                        </div>
                        <div class="row">
                            <p class="card-subtitle mb-2  descripcion"><?php echo e($article -> description); ?></p>
                        </div>
                        <div class="row">
                            <hr>
                        </div>

                        

                        <div class="" id="respuesta-ej<?php echo e($article->id); ?>">
                            <div class="row">
                                <?php echo $article->body; ?>

                                <br>
                            </div>

                            <?php if(! empty($article->video)): ?>
                                <div class="row">
                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="<?php echo e($article->video); ?>"></iframe>
                                    </div>
                                </div>
                            <?php else: ?>
                            <?php endif; ?>


                            <?php if(! empty($article->head_2)): ?>
                                <div class="row ">
                                    <h1 class="card-title"><?php echo e($article ->head_2); ?></h1>
                                    <br>
                                </div>
                            <?php else: ?>
                            <?php endif; ?>

                            <?php if(! empty($article->path_2)): ?>
                                <div class="row">
                                    <img class="card-img-top img-articles" src="../images/<?php echo e($article->path_2); ?>" alt="Card image cap">
                                    <br>
                                </div>

                            <?php else: ?>
                            <?php endif; ?>

                            <?php if(! empty($article->description_2)): ?>
                                <div class="row">
                                    <p class="card-subtitle mb-2  descripcion"><?php echo e($article -> description_2); ?></p>
                                    <br>
                                </div>
                            <?php else: ?>
                            <?php endif; ?>

                            <?php if(! empty($article->body_2)): ?>
                                <div class="row">
                                    <?php echo $article->body_2; ?>

                                    <br>
                                </div>
                            <?php else: ?>
                            <?php endif; ?>

                            <?php if(! empty($article->video_2)): ?>
                                <div class="row">
                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="<?php echo e($article->video_2); ?>"></iframe>
                                    </div>
                                    <br>
                                </div>
                            <?php else: ?>
                            <?php endif; ?>

                            <br>
                            <div class="row">
                                <br>
                                <p>Categoria: <b><?php echo e($article->category); ?></b></p>
                            </div>
                            <div class="row">
                                <p>Posteado por: <b><?php echo e($article->autor); ?></b></p>
                            </div>


                            <div class="row">
                                <hr>
                            </div>
                        </div>

                        
                        <div class="row">
                            <button href="#<?php echo e($article->id); ?>"type="submit" id="alternar-respuesta-ej<?php echo e($article->id); ?>" onClick="ShowHideElement<?php echo e($article->id); ?>()" class="btn btn-info pse">Ver más</button>
                            <a  class="twitter-share-button esp" data-size="large" href="https://twitter.com/home?status=http%3A//indiesonico.com/move/<?php echo e($article->id); ?>">Twittear</a>
                            <div class="fb-share-button esp" data-href="http://indiesonico.com/move/<?php echo e($article ->id); ?>" data-layout="button" data-size="large" data-mobile-iframe="true"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Findiesonico.com%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Compartir</a></div>
                        </div>
                    </div>

                    <script>

                        // $('.caja').hide();
                        $("#respuesta-ej<?php echo e($article->id); ?>").hide();
                        function ShowHideElement<?php echo e($article->id); ?>() {

                            text="";

                            if ($("#alternar-respuesta-ej<?php echo e($article->id); ?>").text()==="Ver más"){
                                $("#respuesta-ej<?php echo e($article->id); ?>").show();
                                text ="Ver menos";
                            }else{
                                $("#respuesta-ej<?php echo e($article->id); ?>").hide();
                                text ="Ver más";
                            }
                            $("#alternar-respuesta-ej<?php echo e($article->id); ?>").html(text);
                        }
                    </script>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $articles->render(); ?>

            </div>
            
            <?php echo $__env->make('tw.twit2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>