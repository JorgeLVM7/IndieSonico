<?php $__env->startSection('content'); ?>
    <div id="carouselExampleSlidesOnly" class="carousel slide fixed-absolute" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100 top-ten" src="icons/1.png" alt="First slide">
            </div>
            <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item ">
                    <img class="d-block w-100 top-ten logo" src="images/<?php echo e($top->path); ?>" alt="">
                    
                        
                        
                            
                        
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>