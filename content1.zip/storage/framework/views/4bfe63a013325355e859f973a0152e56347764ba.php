<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-12">
            <div class="row ">
                <div class="col-12">
                    <div class="row">
                        <div class="col-10">
                            <h1>Crear Usuario</h1>
                        </div>
                        <div class="col-2 ">
                            <a class="btn btn-outline-dark float-right" href="<?php echo e(route('users.index')); ?>">Cancelar</a>
                        </div>
                    </div>
                    <hr>
                    <?php echo $__env->make('users.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('users.fragment.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-12">
                            <?php echo Form::open(['route'=>'users.store']); ?>

                            <?php echo e(csrf_field()); ?>


                            <?php echo $__env->make('users.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>