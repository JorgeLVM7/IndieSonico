<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-12">
          <div class="row">
              <div class="col-10">
                  <h1>Publicaciones</h1>
              </div>
              <div class="col-2">
                  <a class="btn btn-outline-dark float-right" href="<?php echo e(route('articles.create')); ?>">Nuevo</a>
              </div>
          </div>
          <?php echo $__env->make('articles.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <table class="table table-hover ">
              <thead>
                <tr>
                    <th>Encabezado</th>
                    <th>Descripción</th>
                    <th>Categoria</th>
                    <th>Estado</th>
                    <th colspan="3">Acciones</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="<?php echo e($article ->approve); ?>">
                      <td><?php echo e($article ->head); ?></td>
                      <td><?php echo e($article ->description); ?></td>
                      <td><?php echo e($article ->category); ?></td>
                      <td><?php echo e($article ->approve); ?></td>
                      <td>
                        <div class="btn-group btn-group-toggle" >
                          <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="btn btn-outline-success" role="button" aria-pressed="true">Ver</a>

                          <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-outline-warning"  role="button" aria-pressed="true">Editar</a>

                            <form class="btn-group btn-group-toggle" action="<?php echo e(route('articles.destroy', $article->id)); ?>" method="POST">
                              <?php echo e(csrf_field()); ?>

                              <input type="hidden" name="_method" value="DELETE">
                              <button class="btn btn-outline-danger" style="cursor: pointer;" type="submit">Borrar</button>
                          </form>
                        </div>
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
          <?php echo $articles->render(); ?>

      </div>
  </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>