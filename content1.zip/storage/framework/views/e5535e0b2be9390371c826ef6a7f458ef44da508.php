<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="col-12">
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-11">
                        <h1>Crear Usuario</h1>
                    </div>
                    <div class="col-1 ">
                        <a class="btn btn-outline-dark" href="<?php echo e(route('users.index')); ?>">Cancelar</a>
                    </div>
                </div>
                <hr>
                <form class="form-row" method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-6">
                        <div class="form-group<?php echo e($errors->has('user') ? ' has-error' : ''); ?>">
                            <label for="user" class="col-md-12 control-label">Usuario</label>
                            <div class="col-md-12">
                                <input id="user" type="text" class="form-control" name="user" value="<?php echo e(old('user')); ?>" required autofocus>
                                <?php if($errors->has('user')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('user')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-12 control-label">Nombre</label>

                            <div class="col-md-12">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                            <label for="last-name" class="col-md-12 control-label">Apellido</label>

                            <div class="col-md-12">
                                <input id="last_name" type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus>

                                <?php if($errors->has('last_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                            <label for="level" class="col-md-12 control-label">Rol</label>

                            <div class="col-md-12">
                                

                                <select name="level" id="level" class="form-control">
                                    <option value="Editor">Editor</option>
                                    <option value="Administrador">Administrador</option>
                                </select>

                                <?php if($errors->has('level')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('level')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-12 control-label">Correo Electronico</label>

                            <div class="col-md-12">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-12 control-label">Contraseña</label>

                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="password-confirm" class="col-md-12 control-label">Confirmar Contraseña </label>

                            <div class="col-md-12">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                            </div>
                        </div>
                    </div>
                </form>



            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>








































<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>