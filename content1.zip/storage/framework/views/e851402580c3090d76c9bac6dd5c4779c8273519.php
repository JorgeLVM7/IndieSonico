<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-11">
                    <h1>Vista Previa</h1>
                </div>
            </div>
            <hr>
            <div class="col-12">
                
                <h4><?php echo e($article->head); ?></h4>
                
                <p id="descripcion"><?php echo e($article->description); ?></p>
                
                <p class="text-justify"><?php echo e($article->body); ?></p>
                
                <p><?php echo e($article->category); ?> - <b><?php echo e($article->autor); ?></b> </p>

                <img src="/images/<?php echo e($article->path); ?>" class="img-fluid" alt="Responsive image">
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>