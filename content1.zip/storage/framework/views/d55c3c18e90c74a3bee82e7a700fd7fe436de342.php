<div class="row">
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('user','Usuario'); ?>

            <?php echo Form::text('user', null,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('name','Nombre'); ?>

            <?php echo Form::text('name', null,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('last_name','Apellido'); ?>

            <?php echo Form::text('last_name', null,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('level','Nivel '); ?>

            <?php echo Form::select('level',['Administrador'=>'Administrador',
                                        'Editor'=>'Editor']
                                        , null,['class'=>'form-control']
        ); ?>


        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('email','Correo'); ?>

            <?php echo Form::email('email', null,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-12">
        <div class="form-group">
            <?php echo Form::submit('Guardar',['class'=>'btn btn-primary', 'style'=>"cursor: pointer"]); ?>


        </div>
    </div>
</div>









