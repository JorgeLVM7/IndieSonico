<div class="form-group">
    <?php echo Form::label('head','Encabezado del artículo'); ?>

    <?php echo Form::text('head', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('image','Foto'); ?>

    <?php echo Form::file('path'); ?>

</div>

<div class="form-group">
    <?php echo Form::label('description','Descripción '); ?>

    <?php echo Form::text('description', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('body','Cuerpo '); ?>

    <?php echo Form::textarea('body', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('video','Link de Video'); ?>

    <?php echo Form::text('video', null,['class'=>'form-control']); ?>

</div>



<div class="form-group">
    <?php echo Form::label('head_2','Encabezado 2'); ?>

    <?php echo Form::text('head_2', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('image_2','Foto 2'); ?>

    <?php echo Form::file('path_2'); ?>

</div>

<div class="form-group">
    <?php echo Form::label('description_2','Descripción 2'); ?>

    <?php echo Form::text('description_2', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('body_2','Cuerpo 2 '); ?>

    <?php echo Form::textarea('body_2', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('video_2','Link de Video 2'); ?>

    <?php echo Form::text('video_2', null,['class'=>'form-control']); ?>

</div>




<div class="form-group">
    <label for="">Autor</label>
    <h5><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?> </h5>
</div>

<div class="form-group">
    <?php echo Form::label('category','Categoría '); ?>

    <?php echo Form::select('category',['Música'=>'Música',
                                'Cine'=>'Cine',
                                'Moviendo el Indie'=>'Moviendo el Indie',
                                'Artículos'=>'Artículos',
                                'Conciertos'=>'Conciertos',
                                'Random'=>'Random'
                                ]
                                , null,['class'=>'form-control']
); ?>


</div>

<?php echo e(Form::hidden('user_id',auth()->user()->id )); ?>



<div class="form-group">
    <?php echo Form::label('approve','Estado... '); ?>

    <?php echo Form::select('approve',['Aprobado'=>'Aprobado',
                                'Rechazado'=>'Rechazado',
                                'No Aprobado'=>'No Aprobado']
                                , null,['class'=>'form-control']
); ?>


</div>
<div class="form-group">
    <?php echo Form::submit('Guardar',['class'=>'btn btn-primary', 'style'=>"cursor: pointer"]); ?>


</div>

