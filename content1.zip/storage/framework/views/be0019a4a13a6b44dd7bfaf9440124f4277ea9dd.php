<?php $__env->startSection('content'); ?>
    <br>
        
            <div class="row">
                <div class="col-sm-9 bw">
                    <div class="row">
                        <a class="a-redes" href=""><img class="redes" src="icons/face.jpg" alt=""></a>
                    </div>
                    <div class="row">
                        <a class="a-redes" href=""><img class="redes" src="icons/insta.jpg" alt=""></a>
                    </div>
                    <div class="row">
                        <a class="a-redes" href=""><img class="redes" src="icons/youtube.jpg" alt=""></a>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <h1>Contáctanos</h1>
                            
                        </div>
                    </div>
                    <?php echo $__env->make('contact.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-12">
                            <?php echo Form::open(['route'=>'contact.store']); ?>


                            <?php echo $__env->make('contact.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
                
                <?php echo $__env->make('tw.twit2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>