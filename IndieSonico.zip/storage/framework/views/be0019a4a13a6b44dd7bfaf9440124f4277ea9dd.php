<?php $__env->startSection('content-video'); ?>
    <div class="container-fluid">
        <div class="row">
            <video width="100%" height="100%" autoplay loop>
                <source src="../logos/indie.mp4" type="video/mp4">
                <source src="../logos/indie.ogg" type="video/ogg">
            </video>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content1'); ?>
        
            <div class="row">
                <div class="col-sm-12 bw">
                    <div class="row follow">
                        <a class="a-redes" href="https://www.facebook.com/indiesonico/"><img class="redes" src="logos/face.jpg" alt="" style="width: 100%"></a>
                    </div>
                    <div class="row follow">
                        <a class="a-redes" href="https://www.instagram.com/indiesonico/"><img class="redes" src="logos/insta.jpg" alt=""></a>
                    </div>
                    <div class="row follow">
                        <a class="a-redes" href="https://www.youtube.com/channel/UC6C4w1GO4iuIZxqjrmLf7YQ"><img class="redes" src="logos/youtube.jpg" alt=""></a>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <h1>Contáctanos</h1>
                            
                        </div>
                    </div>
                    <?php echo $__env->make('contact.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-12">
                            <?php echo Form::open(['route'=>'contact.store']); ?>


                            <?php echo $__env->make('contact.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>

            </div>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.indie3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>