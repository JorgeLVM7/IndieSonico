<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-10">
                    <h1>Vista Previa</h1>
                </div>
                <div class="col-1">
                    <a class="btn btn-outline-dark float-right" href="<?php echo e(route('carousel.index')); ?>">Regresar</a>
                </div>
                <div class="col-1 ">
                    <a class="btn btn-outline-warning float-right" href="<?php echo e(route('carousel.edit',$top->id)); ?>">Editar</a>
                </div>
            </div>
            <hr>
            <div class="row ">

                
                <div class="col-12">
                    <h1><?php echo e($top->head); ?></h1>
                    <br>
                </div>
                <div class="col-12">
                    <img src="/images/<?php echo e($top->path); ?>" class="img-fluid" alt="">
                    <br>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>