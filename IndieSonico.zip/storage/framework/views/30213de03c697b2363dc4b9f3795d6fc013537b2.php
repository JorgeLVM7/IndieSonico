<div class="form-group">
    <?php echo Form::label('head','Encabezado del artículo'); ?>

    <?php echo Form::text('head', null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('image','Foto'); ?>

    <?php echo Form::file('path'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit('Guardar',['class'=>'btn btn-primary', 'style'=>"cursor: pointer"]); ?>


</div>

