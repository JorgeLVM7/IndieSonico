<?php $__env->startSection('content'); ?>
    <div id="carouselExampleSlidesOnly" class=" carousel slide fixed-absolute ahi" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100 top-ten" src="icons/1.png" alt="First slide">
            </div>
            <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item ">
                    <img class="d-block w-100 top-ten logo" src="images/<?php echo e($top->path); ?>" alt="">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-9 scroll bw">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body">
                        <div class="row ">
                            <h3 class="card-title"><b><?php echo e($article ->head); ?></b></h3>
                        </div>
                        <div class="row ">
                            <img class="card-img-top img-articles" src="images/<?php echo e($article->path); ?>" alt="Card image cap">
                        </div>
                        <div class="row">
                            <p class="card-subtitle mb-2  descripcion"><?php echo e($article -> description); ?></p>
                        </div>
                        <div class="row">
                            <a href="<?php echo e(route('sessionsis.show',$article->id)); ?>" class="btn btn-info pse">Ver más</a>
                            <a  class="twitter-share-button esp" data-size="large" href="https://twitter.com/home?status=http%3A//indiesonico.com/review/<?php echo e($article->id); ?>">Twittear</a>
                            <div class="fb-share-button esp" data-href="http://indiesonico.com/review/<?php echo e($article ->id); ?>" data-layout="button" data-size="large" data-mobile-iframe="true"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Findiesonico.com%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Compartir</a></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $articles->render(); ?>

            </div>
            
            <?php echo $__env->make('tw.twit2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>