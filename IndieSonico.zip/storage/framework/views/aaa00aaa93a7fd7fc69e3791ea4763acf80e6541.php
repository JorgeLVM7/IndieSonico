<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-10">
                    <h1>Vista Previa</h1>
                </div>
                <div class="col-1">
                    <a class="btn btn-outline-dark float-right" href="<?php echo e(route('approvals.index')); ?>">Regresar</a>
                </div>
                <div class="col-1 ">
                    <a class="btn btn-outline-warning float-right" href="<?php echo e(route('approvals.edit',$approval->id)); ?>">Editar</a>
                </div>
            </div>
            <hr>
            <div class="row ">

                
                <div class="col-12">
                    <h1><?php echo e($approval->head); ?></h1>
                    <br>
                </div>
                <div class="col-12">
                    <img src="/images/<?php echo e($approval->path); ?>" class="img-fluid" alt="">
                    <br>
                </div>
                <div class="col-12">
                    <p id="descripcion"><?php echo e($approval->description); ?></p>
                    <br>
                </div>

                <div class="col-12">
                    <?php echo $approval->body; ?>

                    <br>
                </div>

                <?php if(! empty($approval->video)): ?>
                    <div class="col-12">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo e($approval->video); ?>"></iframe>
                        </div>
                        <br>
                    </div>
                <?php else: ?>
                <?php endif; ?>

                

                <?php if(! empty($approval->head_2)): ?>
                    <div class="col-12">
                        <h1><?php echo e($approval->head_2); ?></h1>
                        <br>

                    </div>
                <?php else: ?>
                <?php endif; ?>

                <?php if(! empty($approval->path_2)): ?>
                    <div class="col-12">
                        <img src="/images/<?php echo e($approval->path_2); ?>" class="img-fluid" alt="">
                        <br>
                    </div>
                <?php else: ?>
                <?php endif; ?>


                <?php if(! empty($approval->description_2)): ?>
                    <div class="col-12">
                        <p id="descripcion"><?php echo e($approval->description_2); ?></p>
                        <br>
                    </div>

                <?php else: ?>
                <?php endif; ?>


                <?php if(! empty($approval->body_2)): ?>
                    <div class="col-12">
                        <?php echo $approval->body_2; ?>

                        <br>
                    </div>
                <?php else: ?>
                <?php endif; ?>


                <?php if(! empty($approval->video_2)): ?>
                    <div class="col-12">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo e($approval->video_2); ?>"></iframe>
                        </div>
                        <br>
                    </div>
                <?php else: ?>
                <?php endif; ?>




                <div class="col-12">
                    <p><?php echo e($approval->category); ?></p>
                </div>
                <div class="col-12">
                    <p><b><?php echo e($approval->autor); ?></b></p>
                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>