<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-10">
                    <h1>Publicidad</h1>
                </div>
                <div class="col-2">
                    
                </div>
            </div>
            <?php echo $__env->make('advertising.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <table class="table table-hover ">
                <thead>
                <tr>
                    <th>Encabezado</th>
                    <th>Imagen</th>
                    <th colspan="3">Acciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $advers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($adver ->head); ?></td>
                        <td>
                            <img src="/images/<?php echo e($adver->path); ?>" class="img-fluid" alt="">
                        </td>

                        <td>
                            <div class="btn-group btn-group-toggle" >
                                <a href="<?php echo e(route('advertising.show', $adver->id)); ?>" class="btn btn-outline-success" role="button" aria-pressed="true">Ver</a>

                                <a href="<?php echo e(route('advertising.edit', $adver->id)); ?>" class="btn btn-outline-warning"  role="button" aria-pressed="true">Editar</a>


                                    <?php echo e(csrf_field()); ?>

                                    
                                    
                                </form>

                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $advers->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>