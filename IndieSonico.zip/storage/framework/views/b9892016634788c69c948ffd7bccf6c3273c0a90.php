<?php $__env->startSection('content0'); ?>

    <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div id="tops0" class="card" style="border:none !important;">
            <img class="card-img-top" src="../images/<?php echo e($top->path); ?>" alt="Card image cap" style="height: 112px">
            <a href="<?php echo e(route('show',$top->id)); ?>" class="a-corregido2">
                <h5 class="card-title"><?php echo e($top ->head); ?></h5>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $tops1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div id="tops1" class="card" style="border:none !important;">
            <img class="card-img-top" src="../images/<?php echo e($top1->path); ?>" alt="Card image cap" style="height: 112px">
            <a href="<?php echo e(route('show',$top1->id)); ?>" class="a-corregido2">
                <h5 class="card-title"><?php echo e($top1 ->head); ?></h5>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content1'); ?>

    <div class="row">
        <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-12">
                    <h1><?php echo e($article ->head); ?></h1>
                    <p><?php echo e($article -> description); ?></p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <p>By <?php echo e($article->autor); ?></p>
                </div>
                <div class="col-sm-12">
                    <img class="card-img-top img-articles" src="../images/<?php echo e($article->path); ?>" alt="Card image cap">
                    <br>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <p><?php echo $article->body; ?></p>
                    <br>
                </div>
            </div>

            <?php if(! empty($article->video)): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo e($article->video); ?>"></iframe>
                        </div>
                        <br>
                    </div>

                </div>
            <?php else: ?>
            <?php endif; ?>

            <?php if(! empty($article->head_2)): ?>
                <div class="row ">
                    <div class="col-sm-12">
                        <h1><?php echo e($article->head_2); ?></h1>
                    </div>
                    <br>
                </div>
            <?php else: ?>
            <?php endif; ?>

            <?php if(! empty($article->path_2)): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <img class="card-img-top img-articles" src="../images/<?php echo e($article->path_2); ?>" alt="Card image cap">
                        <br>
                    </div>
                </div>

            <?php else: ?>
            <?php endif; ?>

            <?php if(! empty($article->description_2)): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <p class="card-subtitle mb-2  descripcion"><?php echo e($article -> description_2); ?></p>
                        <br>
                    </div>
                </div>
            <?php else: ?>
            <?php endif; ?>

            <?php if(! empty($article->body_2)): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <p><?php echo $article->body_2; ?></p>
                        <br>
                    </div>
                </div>
            <?php else: ?>
            <?php endif; ?>

            <?php if(! empty($article->video_2)): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo e($article->video_2); ?>"></iframe>
                        </div>
                        <br>
                    </div>
                </div>
            <?php else: ?>
            <?php endif; ?>
        </div>

        
        
        
        
    </div>

    <div class="row">
        <div class="col-sm-12">
            
            <div id="" class="row">
                <a  class="twitter-share-button esp" data-size="large" href="https://twitter.com/home?status=http%3A//indiesonico.com/sessionsis/show/<?php echo e($article->id); ?>">Twittear</a>
                <div class="fb-share-button esp" data-href="http://indiesonico.com/sessionsis/show/<?php echo e($article ->id); ?>" data-layout="button" data-size="large" data-mobile-iframe="true"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Findiesonico.com%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Compartir</a></div>
            </div>
        </div>
    </div>

    <div class="row">
        <br>
    </div>

<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.indie3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>