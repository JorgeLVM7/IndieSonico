<div class="col-sm-3 publicidad">

    <div class="row bw e-banner1">
       <div class="col-12">
           <?php $__currentLoopData = $banners3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <img class="banner1" src="/images/<?php echo e($banner3->path); ?>" alt="">
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php echo $banners3->render(); ?>       </div>
    </div>


    <div class="row bw">
        <div class="col-6 iconos">
            <h4 class="sig">SÍGUENOS</h4>
        </div>
        <div class="col-6 iconos">
            <a href="https://www.facebook.com/indiesonico/" ><img src="/logos/facebook.png" alt=""></a>
            <a href="https://www.instagram.com/indiesonico/"><img src="/logos/instagram.png" alt=""></a>
            <a href="https://twitter.com/IndieSonico"><img src="/logos/twitter.png" alt=""></a>
        </div>
        <hr>
        <div class="col-12 text-center">
            <div class="row text-center">
                <div class="col-12">
                    <span class="siguenos2">¿TIENES UNA BANDA ? </span>
                    <a class="siguenos" href="<?php echo e(route('contact.index')); ?>"><b>ESCRÍBENOS</b></a>
                </div>

            </div>
            <div class="row text-center">
                <div class="col-12">
                    <span class="siguenos2">SUBE TU FOTO/ NOTA /MÚSICA</span>
                    <a class="siguenos" href="<?php echo e(route('contact.index')); ?>"><b>COLABORA</b></a>
                </div>
            </div>

            <div class="row text-center">
                <div class="col-12">
                    <span class="siguenos2" >DUDA / SUGERENCIAS  </span>
                    <a class="siguenos" href="<?php echo e(route('contact.index')); ?>"><b>CONTACTO</b></a>
                </div>

            </div>
            <div class="row">
                <br>
            </div>
        </div>
    </div>

</div>
