<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-10">
                    <h1>Vista Previa</h1>
                </div>
                <div class="col-1">
                    <a class="btn btn-outline-dark float-right" href="<?php echo e(route('articles.index')); ?>">Regresar</a>
                </div>
                <div class="col-1 ">
                    <a class="btn btn-outline-warning float-right" href="<?php echo e(route('articles.edit',$article->id)); ?>">Editar</a>
                </div>
            </div>
            <hr>
            <div class="row ">

                
                <div class="col-12">
                    <h1><?php echo e($article->head); ?></h1>
                    <br>
                </div>
                <div class="col-12">
                    <img src="/images/<?php echo e($article->path); ?>" class="img-fluid" alt="">
                    <br>
                </div>
                <div class="col-12">
                    <p id="descripcion"><?php echo e($article->description); ?></p>
                    <br>
                </div>

                <div class="col-12">
                    <?php echo $article->body; ?>

                    <br>
                </div>

                <?php if(! empty($article->video)): ?>
                <div class="col-12">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" src="<?php echo e($article->video); ?>"></iframe>
                    </div>
                    <br>
                </div>
                <?php else: ?>
                <?php endif; ?>

                

                <?php if(! empty($article->head_2)): ?>
                <div class="col-12">
                    <h1><?php echo e($article->head_2); ?></h1>
                    <br>

                </div>
                <?php else: ?>
                <?php endif; ?>

                <?php if(! empty($article->path_2)): ?>
                <div class="col-12">
                    <img src="/images/<?php echo e($article->path_2); ?>" class="img-fluid" alt="">
                    <br>
                </div>
                <?php else: ?>
                <?php endif; ?>


                <?php if(! empty($article->description_2)): ?>
                <div class="col-12">
                    <p id="descripcion"><?php echo e($article->description_2); ?></p>
                    <br>
                </div>

                <?php else: ?>
                <?php endif; ?>


                <?php if(! empty($article->body_2)): ?>
                <div class="col-12">
                        <?php echo $article->body_2; ?>

                        <br>
                    </div>
                <?php else: ?>
                <?php endif; ?>


                <?php if(! empty($article->video_2)): ?>
                <div class="col-12">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" src="<?php echo e($article->video_2); ?>"></iframe>
                    </div>
                    <br>
                </div>
                <?php else: ?>
                <?php endif; ?>




                <div class="col-12">
                    <p><?php echo e($article->category); ?></p>
                </div>
                <div class="col-12">
                    <p><b><?php echo e($article->autor); ?></b></p>
                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>