<?php $__env->startSection('content-video'); ?>
    <div class="container-fluid">
        <div class="row">
            <video width="100%" height="100%" autoplay loop>
                <source src="../logos/indie.mp4" type="video/mp4">
                <source src="../logos/indie.ogg" type="video/ogg">
            </video>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content0'); ?>

    <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="tops0" class="card" style="border:none !important;">
            <img class="card-img-top" src="../images/<?php echo e($top->path); ?>" alt="Card image cap" style="height: 112px">
            <a href="<?php echo e(route('show',$top->id)); ?>" class="a-corregido2">
                <h5 class="card-title"><?php echo e($top ->head); ?></h5>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $tops1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div id="tops1" class="col-6">
            <img class="card-img-top" src="../images/<?php echo e($top1->path); ?>" alt="Card image cap" style="height: 112px">
            <a href="<?php echo e(route('show',$top1->id)); ?>" class="a-corregido2">
                <h5 class="card-title"><?php echo e($top1 ->head); ?></h5>
            </a>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content1'); ?>

    <?php $__currentLoopData = $last_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last_article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div id="" class="carousel slide" data-ride="carousel">
            <a class="a-first-notice" href="<?php echo e(route('sessionsis.show',$last_article->id)); ?>">
                <div class="carousel-inner a-first-notice">
                    <div class="carousel-item active">
                        <img class="d-block w-100 img-first-notice" src="images/<?php echo e($last_article->path); ?>" alt="First slide">
                        <div class="carousel-caption d-none d-md-block caja-first-notice">
                            <a class="a-corregido2" href=""><h1 class="h1-first-notice"><?php echo e($last_article->head); ?></h1>
                                <p class="p-first-notice"><?php echo e($last_article->description); ?> </p></a>
                        </div>
                    </div>
                </div>
            </a>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="container">
        <div class="row">
            <div class="col-12">
                <br>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row" style="margin-bottom: 10px">
            <div class="col-sm-6">
                <a href="<?php echo e(route('sessionsis.show', $article->id)); ?>" class="a-corregido2">
                    <h1 class="card-title"><?php echo e($article ->head); ?></h1>
                </a>
                <p class="card-subtitle mb-2  descripcion"><?php echo e($article -> description); ?></p>
                <p><?php echo e($article->category); ?></p>
                <p>By <?php echo e($article->autor); ?></p>
            </div>
            <div class="col-sm-6">
                <div class="row">
                    <img class="card-img-top img-articles" src="images/<?php echo e($article->path); ?>" alt="Card image cap">

                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.indie3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>