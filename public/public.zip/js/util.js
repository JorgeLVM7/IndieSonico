$(function(){
    $('#body').trumbowyg();
    $('#body_2').trumbowyg();
});

